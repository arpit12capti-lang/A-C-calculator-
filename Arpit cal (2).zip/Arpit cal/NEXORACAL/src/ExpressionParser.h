#pragma once
#include <string>
#include <stdexcept>
#include <cmath>

class ExpressionParser {
public:
    ExpressionParser();
    
    // Evaluates a mathematical expression string
    double evaluate(const std::string& expression, bool isDegreeMode = true);

private:
    std::string expr;
    size_t pos;
    bool degreeMode;

    double parseExpression();
    double parseTerm();
    double parseFactor();
    double parsePower();
    double parseFactorial();
    double parsePrimary();

    void skipWhitespace();
    char peek();
    char get();
    bool match(char expected);
    std::string parseFunctionName();
    
    // Factorial helper
    double factorial(double n);
};
