#include "HistoryManager.h"

void HistoryManager::addEntry(const std::string& expr, const std::string& res) {
    if (!expr.empty() && !res.empty()) {
        history.push_back({expr, res});
    }
}

void HistoryManager::clear() {
    history.clear();
}

const std::vector<HistoryEntry>& HistoryManager::getHistory() const {
    return history;
}
