#include "MainWindow.h"
#include <QKeyEvent>
#include <QFile>
#include <QApplication>
#include <QRegularExpression>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), resetOnNextInput(false) {
    setupUI();
    loadStyle();
    setWindowTitle("NEXORACAL");
    setMinimumSize(800, 600);
}

void MainWindow::setupUI() {
    QWidget* centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);

    QHBoxLayout* mainLayout = new QHBoxLayout(centralWidget);
    mainLayout->setContentsMargins(10, 10, 10, 10);
    mainLayout->setSpacing(10);

    // Left Panel: History
    QWidget* historyPanel = new QWidget(this);
    QVBoxLayout* historyLayout = new QVBoxLayout(historyPanel);
    historyLayout->setContentsMargins(0, 0, 0, 0);

    QLabel* historyTitle = new QLabel("History", this);
    historyTitle->setStyleSheet("font-size: 16px; font-weight: bold; color: #888;");
    historyList = new QListWidget(this);
    connect(historyList, &QListWidget::itemClicked, this, &MainWindow::onHistoryItemClicked);

    QPushButton* clearHistoryBtn = new QPushButton("Clear History", this);
    clearHistoryBtn->setObjectName("actionBtn");
    connect(clearHistoryBtn, &QPushButton::clicked, this, &MainWindow::onClearHistory);

    historyLayout->addWidget(historyTitle);
    historyLayout->addWidget(historyList);
    historyLayout->addWidget(clearHistoryBtn);

    // Right Panel: Calculator
    QWidget* calcPanel = new QWidget(this);
    QVBoxLayout* calcLayout = new QVBoxLayout(calcPanel);
    calcLayout->setContentsMargins(0, 0, 0, 0);

    // Top Controls (Mode & Sci Toggle)
    QHBoxLayout* topControlsLayout = new QHBoxLayout();
    sciToggleBtn = new QPushButton("Scientific", this);
    sciToggleBtn->setCheckable(true);
    sciToggleBtn->setObjectName("modeBtn");
    connect(sciToggleBtn, &QPushButton::clicked, this, &MainWindow::toggleScientificPanel);

    modeBtn = new QPushButton("DEG", this);
    modeBtn->setObjectName("modeBtn");
    connect(modeBtn, &QPushButton::clicked, this, &MainWindow::onModeToggle);

    topControlsLayout->addWidget(sciToggleBtn);
    topControlsLayout->addStretch();
    topControlsLayout->addWidget(modeBtn);

    // Display Area
    QWidget* displayWidget = new QWidget(this);
    displayWidget->setObjectName("displayPanel");
    QVBoxLayout* displayLayout = new QVBoxLayout(displayWidget);
    
    expressionLabel = new QLabel("", this);
    expressionLabel->setObjectName("expressionLabel");
    expressionLabel->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    
    inputDisplay = new QLineEdit("0", this);
    inputDisplay->setObjectName("inputDisplay");
    inputDisplay->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    inputDisplay->setReadOnly(true);

    displayLayout->addWidget(expressionLabel);
    displayLayout->addWidget(inputDisplay);

    // Keypad Area
    QHBoxLayout* keypadLayout = new QHBoxLayout();

    // Scientific Panel
    scientificPanel = new QWidget(this);
    QGridLayout* sciLayout = new QGridLayout(scientificPanel);
    scientificPanel->setVisible(false); // Hidden by default
    
    QStringList sciButtons = {
        "sin", "cos", "tan",
        "asin", "acos", "atan",
        "log", "ln", "sqrt",
        "^2", "^", "!",
        "pi", "e", "(", ")"
    };

    int row = 0, col = 0;
    for (const QString& text : sciButtons) {
        QPushButton* btn = new QPushButton(text, this);
        btn->setObjectName("sciBtn");
        connect(btn, &QPushButton::clicked, this, &MainWindow::onScientificButtonClicked);
        sciLayout->addWidget(btn, row, col);
        col++;
        if (col > 2) { col = 0; row++; }
    }

    // Basic Panel
    QWidget* basicPanel = new QWidget(this);
    QGridLayout* basicLayout = new QGridLayout(basicPanel);

    QStringList basicButtons = {
        "MC", "MR", "M+", "M-",
        "AC", "DEL", "%", "/",
        "7", "8", "9", "*",
        "4", "5", "6", "-",
        "1", "2", "3", "+",
        "+/-", "0", ".", "="
    };

    row = 0; col = 0;
    for (const QString& text : basicButtons) {
        QPushButton* btn = new QPushButton(text, this);
        if (text == "=") btn->setObjectName("equalsBtn");
        else if (text == "AC" || text == "DEL") btn->setObjectName("actionBtn");
        else if (text == "MC" || text == "MR" || text == "M+" || text == "M-") btn->setObjectName("memoryBtn");
        else if (QString("/*-+%").contains(text)) btn->setObjectName("opBtn");
        else btn->setObjectName("numBtn");

        if (text == "AC") connect(btn, &QPushButton::clicked, this, &MainWindow::onClear);
        else if (text == "DEL") connect(btn, &QPushButton::clicked, this, &MainWindow::onDelete);
        else if (text == "=") connect(btn, &QPushButton::clicked, this, &MainWindow::onCalculate);
        else if (text == "+/-") connect(btn, &QPushButton::clicked, this, &MainWindow::onToggleSign);
        else if (text == "MC") connect(btn, &QPushButton::clicked, this, &MainWindow::onMemoryClear);
        else if (text == "MR") connect(btn, &QPushButton::clicked, this, &MainWindow::onMemoryRecall);
        else if (text == "M+") connect(btn, &QPushButton::clicked, this, &MainWindow::onMemoryAdd);
        else if (text == "M-") connect(btn, &QPushButton::clicked, this, &MainWindow::onMemorySubtract);
        else connect(btn, &QPushButton::clicked, this, &MainWindow::onButtonClicked);

        basicLayout->addWidget(btn, row, col);
        col++;
        if (col > 3) { col = 0; row++; }
    }

    keypadLayout->addWidget(scientificPanel);
    keypadLayout->addWidget(basicPanel);

    calcLayout->addLayout(topControlsLayout);
    calcLayout->addWidget(displayWidget);
    calcLayout->addLayout(keypadLayout);

    mainLayout->addWidget(historyPanel, 1);
    mainLayout->addWidget(calcPanel, 3);
}

void MainWindow::loadStyle() {
    QFile file(":/style.qss");
    if (file.open(QFile::ReadOnly)) {
        QString styleSheet = QLatin1String(file.readAll());
        qApp->setStyleSheet(styleSheet);
    } else {
        // Fallback style if QRC fails
        setStyleSheet(R"(
            QMainWindow { background-color: #121212; color: #ffffff; }
            QWidget { font-family: 'Segoe UI', Arial, sans-serif; }
            #displayPanel { background-color: #1e1e1e; border-radius: 10px; padding: 10px; }
            #expressionLabel { color: #aaaaaa; font-size: 16px; }
            #inputDisplay { background: transparent; border: none; color: #ffffff; font-size: 42px; font-weight: bold; }
            QPushButton { border-radius: 8px; font-size: 18px; padding: 15px; border: 1px solid #333; background-color: #2c2c2c; color: white; }
            QPushButton:hover { background-color: #3e3e3e; }
            QPushButton:pressed { background-color: #555555; }
            #actionBtn { background-color: #d32f2f; }
            #actionBtn:hover { background-color: #f44336; }
            #equalsBtn { background-color: #1976d2; }
            #equalsBtn:hover { background-color: #2196f3; }
            #opBtn { background-color: #ff9800; color: black; font-weight: bold; }
            #opBtn:hover { background-color: #ffb74d; }
            #numBtn { background-color: #424242; }
            #numBtn:hover { background-color: #616161; }
            QListWidget { background-color: #1e1e1e; border: none; border-radius: 8px; padding: 5px; color: #fff; }
            QListWidget::item:hover { background-color: #333; }
            QListWidget::item:selected { background-color: #1976d2; }
        )");
    }
}

void MainWindow::updateDisplay() {
    if (currentExpression.empty()) {
        inputDisplay->setText("0");
    } else {
        inputDisplay->setText(QString::fromStdString(currentExpression));
    }
}

void MainWindow::addToInput(const QString& text) {
    if (resetOnNextInput) {
        if (!QString("/*-+%^").contains(text)) {
            currentExpression = "";
        }
        resetOnNextInput = false;
        expressionLabel->setText("");
    }
    currentExpression += text.toStdString();
    updateDisplay();
}

void MainWindow::onButtonClicked() {
    QPushButton* btn = qobject_cast<QPushButton*>(sender());
    if (btn) {
        addToInput(btn->text());
    }
}

void MainWindow::onScientificButtonClicked() {
    QPushButton* btn = qobject_cast<QPushButton*>(sender());
    if (!btn) return;
    
    QString text = btn->text();
    if (text == "^2") {
        addToInput("^2");
    } else if (text == "pi" || text == "e" || text == "(" || text == ")" || text == "^" || text == "!") {
        addToInput(text);
    } else {
        addToInput(text + "(");
    }
}

void MainWindow::onCalculate() {
    if (currentExpression.empty()) return;

    std::string result = engine.evaluate(currentExpression);
    
    // Check if it is an error message
    bool isError = false;
    if (result.find("error") != std::string::npos || result.find("Cannot") != std::string::npos || result.find("Invalid") != std::string::npos) {
        isError = true;
    } else {
        historyManager.addEntry(currentExpression, result);
        QListWidgetItem* item = new QListWidgetItem(QString::fromStdString(currentExpression + " = " + result));
        historyList->insertItem(0, item);
    }

    expressionLabel->setText(QString::fromStdString(currentExpression + " ="));
    
    currentExpression = isError ? result : result; // On error, show error string
    inputDisplay->setText(QString::fromStdString(currentExpression));
    
    if (isError) {
        currentExpression = "";
    }
    
    resetOnNextInput = true;
}

void MainWindow::onClear() {
    currentExpression = "";
    expressionLabel->setText("");
    updateDisplay();
    resetOnNextInput = false;
}

void MainWindow::onDelete() {
    if (resetOnNextInput) {
        onClear();
        return;
    }
    if (!currentExpression.empty()) {
        currentExpression.pop_back();
        updateDisplay();
    }
}

void MainWindow::onToggleSign() {
    if (currentExpression.empty() || currentExpression == "0") return;
    if (currentExpression[0] == '-') {
        currentExpression = currentExpression.substr(1);
    } else {
        currentExpression = "-" + currentExpression;
    }
    updateDisplay();
}

void MainWindow::onModeToggle() {
    bool isDeg = engine.isDegreeMode();
    engine.setDegreeMode(!isDeg);
    modeBtn->setText(engine.isDegreeMode() ? "DEG" : "RAD");
}

void MainWindow::onHistoryItemClicked(QListWidgetItem* item) {
    QString text = item->text();
    QStringList parts = text.split(" = ");
    if (parts.size() == 2) {
        currentExpression = parts[0].toStdString();
        updateDisplay();
        resetOnNextInput = false;
        expressionLabel->setText("");
    }
}

void MainWindow::onClearHistory() {
    historyManager.clear();
    historyList->clear();
}

void MainWindow::onMemoryClear() {
    engine.memoryClear();
}

void MainWindow::onMemoryRecall() {
    if (resetOnNextInput) {
        currentExpression = "";
        resetOnNextInput = false;
    }
    engine.memoryRecall(currentExpression);
    updateDisplay();
}

void MainWindow::onMemoryAdd() {
    engine.memoryAdd(currentExpression);
    resetOnNextInput = true;
}

void MainWindow::onMemorySubtract() {
    engine.memorySubtract(currentExpression);
    resetOnNextInput = true;
}

void MainWindow::toggleScientificPanel() {
    scientificPanel->setVisible(sciToggleBtn->isChecked());
}

void MainWindow::keyPressEvent(QKeyEvent *event) {
    QString text = event->text();
int key = event->key();

    if (key == Qt::Key_Enter || key == Qt::Key_Return || key == Qt::Key_Equal) {
        onCalculate();
    } else if (key == Qt::Key_Backspace) {
        onDelete();
    } else if (key == Qt::Key_Escape) {
        onClear();
    } else if (!text.isEmpty()) {
        if (text[0].isDigit() || QString("/*-+().^!%").contains(text)) {
            addToInput(text);
        }
    }
}
