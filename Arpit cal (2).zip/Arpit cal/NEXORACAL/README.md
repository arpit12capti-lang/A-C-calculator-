# NEXORACAL
Advanced Desktop Calculator built with C++ and Qt6.

## Overview
NEXORACAL is a premium, modern desktop scientific calculator designed for both everyday use and complex scientific calculations. It features a clean, responsive, dark-themed UI and a robust recursive-descent mathematical parser engine.

## Features
- **Basic Arithmetic**: Addition, subtraction, multiplication, division, modulo.
- **Scientific Operations**: Trigonometry (sin, cos, tan, asin, acos, atan), Logarithms, Square root, Powers, Factorial.
- **Constants**: PI (π) and Euler's number (e).
- **Mode Switching**: Seamless toggle between DEG (Degrees) and RAD (Radians) for trigonometric functions.
- **History Management**: Automatically saves past calculations. Click on a past calculation to reuse it.
- **Memory Operations**: MC (Memory Clear), MR (Memory Recall), M+ (Memory Add), M- (Memory Subtract).
- **Keyboard Support**: Full keyboard input support (Numpad, +, -, *, /, Enter, Backspace, Esc).
- **Error Handling**: Friendly error messages for division by zero, invalid expressions, or mathematically impossible operations.

## Project Structure
The project separates the mathematical logic from the user interface.
```
NEXORACAL/
├── CMakeLists.txt              # CMake configuration
├── README.md                   # Project documentation
├── src/
│   ├── main.cpp                # Application entry point
│   ├── MainWindow.h/cpp        # Qt6 User Interface & UI logic mapping
│   ├── CalculatorEngine.h/cpp  # Wrapper to normalize input and format output
│   ├── ExpressionParser.h/cpp  # Core Math Engine (Recursive Descent Parser)
│   └── HistoryManager.h/cpp    # History data structure and logic
```

## How It Works
- **UI (MainWindow)**: Collects input either from button clicks or keyboard events and passes it as a string to the `CalculatorEngine`.
- **Engine (CalculatorEngine)**: Takes raw strings (e.g. `sin(30) + π * 2`), normalizes special symbols (`π` to `pi`, `×` to `*`), and passes them to the Parser.
- **Parser (ExpressionParser)**: Uses a custom recursive descent parsing algorithm to evaluate the string while respecting standard mathematical operator precedence (BODMAS/PEMDAS) and parentheses.
- **HistoryManager**: Keeps a list of equations and answers, feeding them into the Qt `QListWidget` on the UI.

## Build Requirements
- **C++ Compiler**: A C++17 compatible compiler (MSVC, GCC, MinGW).
- **CMake**: Version 3.16 or newer.
- **Qt6**: Core and Widgets modules.

### Installing Requirements on Windows
If you do not have Qt6 or CMake installed:
1. Download the [Qt Online Installer](https://www.qt.io/download-qt-installer) and install Qt 6.x for your compiler (e.g., MinGW or MSVC).
2. Install [CMake](https://cmake.org/download/).
3. Make sure CMake and your compiler are in your system PATH.

## Build Instructions (Windows/Linux/macOS)

Open your terminal or command prompt and navigate to the `NEXORACAL` folder:
```bash
# 1. Configure the build
cmake -S . -B build

# Note: If Qt is not in your PATH, you may need to specify its prefix:
# cmake -S . -B build -DCMAKE_PREFIX_PATH="C:/Qt/6.x.x/mingw_64"

# 2. Build the project
cmake --build build --config Release
```

## Running the Application
After a successful build, the executable will be in the `build` directory:
- **Windows**: `build\Release\NEXORACAL.exe` or `build\NEXORACAL.exe`

## Testing Checklist
The engine and UI have been verified to successfully handle:
- [x] Basic math: `2 + 2 = 4`, `10 - 3 = 7`, `5 * 6 = 30`, `20 / 4 = 5`
- [x] Division by zero: `10 / 0` yields `Cannot divide by zero`
- [x] Operator precedence: `2 + 3 * 4 = 14`
- [x] Parentheses: `(2 + 3) * 4 = 20`
- [x] Scientific functions: `sqrt(144) = 12`, `2^5 = 32`, `5! = 120`
- [x] Trigonometry: `sin(30)` in DEG mode yields `0.5`
- [x] Keyboard input integration (Enter calculates, Backspace deletes, Esc clears)
- [x] AC and History functions
- [x] Memory functions (M+, M-, MC, MR)
