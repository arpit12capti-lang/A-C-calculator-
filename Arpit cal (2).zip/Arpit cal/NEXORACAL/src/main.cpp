#include <QApplication>
#include "MainWindow.h"

int main(int argc, char *argv[]) {
    // Enable High DPI scaling
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QApplication app(argc, argv);
    app.setApplicationName("SHRUTI CAL");
    app.setApplicationVersion("1.0");

    MainWindow window;
    window.show();

    return app.exec();
}