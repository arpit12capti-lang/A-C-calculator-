#pragma once
#include <string>
#include "ExpressionParser.h"

class CalculatorEngine {
public:
    CalculatorEngine();

    void setDegreeMode(bool degree);
    bool isDegreeMode() const;

    // Evaluates a user-facing string and returns the result or error string
    std::string evaluate(const std::string& input);

    // Memory operations
    void memoryClear();
    void memoryRecall(std::string& currentInput);
    void memoryAdd(const std::string& input);
    void memorySubtract(const std::string& input);

private:
    ExpressionParser parser;
    bool degreeMode;
    double memoryValue;
    
    std::string normalizeExpression(const std::string& input);
    std::string formatResult(double value);
};
