#include "CalculatorEngine.h"
#include <sstream>
#include <iomanip>
#include <cmath>

CalculatorEngine::CalculatorEngine() : degreeMode(true), memoryValue(0.0) {}

void CalculatorEngine::setDegreeMode(bool degree) {
    degreeMode = degree;
}

bool CalculatorEngine::isDegreeMode() const {
    return degreeMode;
}

std::string CalculatorEngine::normalizeExpression(const std::string& input) {
    std::string expr = input;
    
    // Replace visual symbols with parser-friendly symbols
    auto replaceAll = [](std::string& str, const std::string& from, const std::string& to) {
        if(from.empty()) return;
        size_t start_pos = 0;
        while((start_pos = str.find(from, start_pos)) != std::string::npos) {
            str.replace(start_pos, from.length(), to);
            start_pos += to.length();
        }
    };

    replaceAll(expr, "×", "*");
    replaceAll(expr, "÷", "/");
    replaceAll(expr, "π", "pi");
    replaceAll(expr, "√", "sqrt");
    replaceAll(expr, "²", "^2");
    
    return expr;
}

std::string CalculatorEngine::formatResult(double value) {
    if (std::isnan(value) || std::isinf(value)) {
        return "Math error";
    }

    // Format avoiding trailing zeros
    std::ostringstream out;
    out << std::setprecision(12) << value;
    return out.str();
}

std::string CalculatorEngine::evaluate(const std::string& input) {
    if (input.empty()) return "";

    std::string normalized = normalizeExpression(input);
    try {
        double result = parser.evaluate(normalized, degreeMode);
        return formatResult(result);
    } catch (const std::exception& e) {
        return e.what(); // Return "Cannot divide by zero" etc.
    }
}

void CalculatorEngine::memoryClear() {
    memoryValue = 0.0;
}

void CalculatorEngine::memoryRecall(std::string& currentInput) {
    if (memoryValue != 0.0) {
        currentInput += formatResult(memoryValue);
    }
}

void CalculatorEngine::memoryAdd(const std::string& input) {
    std::string resultStr = evaluate(input);
    try {
        double val = std::stod(resultStr);
        memoryValue += val;
    } catch (...) {
        // Do nothing if current input doesn't evaluate to a valid number
    }
}

void CalculatorEngine::memorySubtract(const std::string& input) {
    std::string resultStr = evaluate(input);
    try {
        double val = std::stod(resultStr);
        memoryValue -= val;
    } catch (...) {
    }
}
