#pragma once
#include <string>
#include <vector>

struct HistoryEntry {
    std::string expression;
    std::string result;
};

class HistoryManager {
public:
    void addEntry(const std::string& expr, const std::string& res);
    void clear();
    const std::vector<HistoryEntry>& getHistory() const;

private:
    std::vector<HistoryEntry> history;
};
