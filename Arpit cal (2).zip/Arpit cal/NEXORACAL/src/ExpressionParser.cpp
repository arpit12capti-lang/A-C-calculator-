#include "ExpressionParser.h"
#include <cctype>
#include <cmath>
#include <stdexcept>
#include <vector>

const double PI = 3.14159265358979323846;
const double E = 2.71828182845904523536;

ExpressionParser::ExpressionParser() : pos(0), degreeMode(true) {}

double ExpressionParser::evaluate(const std::string& expression, bool isDegreeMode) {
    this->expr = expression;
    this->pos = 0;
    this->degreeMode = isDegreeMode;

    if (expr.empty()) return 0.0;

    double result = parseExpression();
    
    skipWhitespace();
    if (pos < expr.length()) {
        throw std::runtime_error("Invalid expression");
    }

    return result;
}

void ExpressionParser::skipWhitespace() {
    while (pos < expr.length() && std::isspace(expr[pos])) {
        pos++;
    }
}

char ExpressionParser::peek() {
    skipWhitespace();
    if (pos < expr.length()) {
        return expr[pos];
    }
    return '\0';
}

char ExpressionParser::get() {
    skipWhitespace();
    if (pos < expr.length()) {
        return expr[pos++];
    }
    return '\0';
}

bool ExpressionParser::match(char expected) {
    if (peek() == expected) {
        pos++;
        return true;
    }
    return false;
}

std::string ExpressionParser::parseFunctionName() {
    std::string name;
    skipWhitespace();
    while (pos < expr.length() && std::isalpha(expr[pos])) {
        name += expr[pos++];
    }
    return name;
}

double ExpressionParser::factorial(double n) {
    if (n < 0 || std::floor(n) != n) {
        throw std::runtime_error("Math error: factorial of non-integer or negative");
    }
    if (n > 170) {
        throw std::runtime_error("Math error: overflow");
    }
    double res = 1;
    for (int i = 2; i <= static_cast<int>(n); ++i) {
        res *= i;
    }
    return res;
}

double ExpressionParser::parseExpression() {
    double value = parseTerm();
    while (true) {
        if (match('+')) {
            value += parseTerm();
        } else if (match('-')) {
            value -= parseTerm();
        } else {
            break;
        }
    }
    return value;
}

double ExpressionParser::parseTerm() {
    double value = parseFactor();
    while (true) {
        if (match('*') || match(0xD7)) { // handle standard and multi symbol if needed, assuming ascii for now
            value *= parseFactor();
        } else if (match('/')) {
            double divisor = parseFactor();
            if (divisor == 0.0) throw std::runtime_error("Cannot divide by zero");
            value /= divisor;
        } else if (match('%')) {
            double divisor = parseFactor();
            if (divisor == 0.0) throw std::runtime_error("Cannot divide by zero");
            value = std::fmod(value, divisor);
        } else {
            break;
        }
    }
    return value;
}

double ExpressionParser::parseFactor() {
    double value = parsePower();
    return value;
}

double ExpressionParser::parsePower() {
    double value = parseFactorial();
    while (true) {
        if (match('^')) {
            value = std::pow(value, parsePower()); // right associative
        } else {
            break;
        }
    }
    return value;
}

double ExpressionParser::parseFactorial() {
    double value = parsePrimary();
    while (match('!')) {
        value = factorial(value);
    }
    return value;
}

double ExpressionParser::parsePrimary() {
    skipWhitespace();
    if (pos >= expr.length()) {
        throw std::runtime_error("Invalid expression");
    }

    char ch = expr[pos];
    
    // Handle unary minus
    if (match('-')) {
        return -parsePrimary();
    }
    // Handle unary plus
    if (match('+')) {
        return parsePrimary();
    }

    // Handle numbers
    if (std::isdigit(ch) || ch == '.') {
        size_t start = pos;
        bool hasDecimal = false;
        while (pos < expr.length() && (std::isdigit(expr[pos]) || expr[pos] == '.')) {
            if (expr[pos] == '.') {
                if (hasDecimal) throw std::runtime_error("Invalid expression");
                hasDecimal = true;
            }
            pos++;
        }
        return std::stod(expr.substr(start, pos - start));
    }

    // Handle parentheses
    if (match('(')) {
        double value = parseExpression();
        if (!match(')')) {
            throw std::runtime_error("Invalid expression: missing closing parenthesis");
        }
        return value;
    }

    // Handle constants and functions
    if (std::isalpha(ch)) {
        std::string name = parseFunctionName();
        
        if (name == "pi" || name == "PI" || name == "π") return PI;
        if (name == "e" || name == "E") return E;
        
        if (match('(')) {
            double arg = parseExpression();
            if (!match(')')) {
                throw std::runtime_error("Invalid expression: missing closing parenthesis");
            }
            
            double multiplier = degreeMode ? (PI / 180.0) : 1.0;
            double inverseMultiplier = degreeMode ? (180.0 / PI) : 1.0;

            if (name == "sin") return std::sin(arg * multiplier);
            if (name == "cos") return std::cos(arg * multiplier);
            if (name == "tan") {
                if (std::abs(std::fmod(arg + 90.0, 180.0)) < 1e-10 && degreeMode) {
                    throw std::runtime_error("Math error: tan undefined");
                }
                return std::tan(arg * multiplier);
            }
            if (name == "asin") {
                if (arg < -1 || arg > 1) throw std::runtime_error("Math error");
                return std::asin(arg) * inverseMultiplier;
            }
            if (name == "acos") {
                if (arg < -1 || arg > 1) throw std::runtime_error("Math error");
                return std::acos(arg) * inverseMultiplier;
            }
            if (name == "atan") return std::atan(arg) * inverseMultiplier;
            if (name == "log") {
                if (arg <= 0) throw std::runtime_error("Math error");
                return std::log10(arg);
            }
            if (name == "ln") {
                if (arg <= 0) throw std::runtime_error("Math error");
                return std::log(arg);
            }
            if (name == "sqrt") {
                if (arg < 0) throw std::runtime_error("Math error");
                return std::sqrt(arg);
            }
        }
        throw std::runtime_error("Invalid expression: unknown function " + name);
    }
    
    // Also handle unicode Pi symbol π which is a multibyte character in UTF-8
    // Actually simpler to let the Engine replace π with pi before parsing.

    throw std::runtime_error("Invalid expression");
}
