#pragma once

#include <QMainWindow>
#include <QLabel>
#include <QListWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLineEdit>
#include "CalculatorEngine.h"
#include "HistoryManager.h"

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);

protected:
    void keyPressEvent(QKeyEvent *event) override;

private slots:
    void onButtonClicked();
    void onScientificButtonClicked();
    void onCalculate();
    void onClear();
    void onDelete();
    void onToggleSign();
    void onModeToggle();
    void onHistoryItemClicked(QListWidgetItem* item);
    void onClearHistory();
    void onMemoryClear();
    void onMemoryRecall();
    void onMemoryAdd();
    void onMemorySubtract();
    void toggleScientificPanel();

private:
    void setupUI();
    void updateDisplay();
    void loadStyle();
    void addToInput(const QString& text);
    
    QLabel* expressionLabel;
    QLineEdit* inputDisplay;
    QListWidget* historyList;
    QWidget* scientificPanel;
    QPushButton* modeBtn;
    QPushButton* sciToggleBtn;

    CalculatorEngine engine;
    HistoryManager historyManager;

    std::string currentExpression;
    bool resetOnNextInput;
};
